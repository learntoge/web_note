﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello,My name is HuangJingwei.This is my first csharp program");
            Console.WriteLine("我的c#之旅开始了");
            Console.ReadKey();
        }
    }
}
