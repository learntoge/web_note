﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace class_1
{
    public partial class WelcomeWinForm : Form
    {
        public WelcomeWinForm()
        {
            InitializeComponent();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {

            this.label1.Text = "welcome c#";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void WelcomeWinForm_Load(object sender, EventArgs e)
        {

        }
    }
}
