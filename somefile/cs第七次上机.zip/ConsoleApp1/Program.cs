﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string input = "0";
            int max = 0;
            Console.WriteLine("请输入数字，输入end结束");
            do
            {
                input = Console.ReadLine();

                if (input != "end")
                {
                    try
                    {
                        if (Convert.ToInt32(input) > max && input != null)
                        {
                            max = Convert.ToInt32(input);
                        }
                    }
                    catch
                    {
                        Console.WriteLine("你输入的数据不合法");
                    }
                }
                else
                {
                    Console.WriteLine("退出成功");
                    break;
                }
            } while (true);
            Console.WriteLine("最大值为：{0}", max);
        }
    }
}
