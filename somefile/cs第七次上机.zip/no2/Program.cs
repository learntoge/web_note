﻿namespace no2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int i = 100; i < 1000; i++)
            {
                int bai = i / 100, shi = i / 10 % 10, ge = i % 10;
                if (Math.Pow(bai,3)+ Math.Pow(shi, 3) + Math.Pow(ge, 3) == i) {
                    Console.WriteLine("{0}\t是水仙花数",i);
                }

            }
            
        }
    }
}
