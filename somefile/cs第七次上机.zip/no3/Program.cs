﻿namespace no3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("请输入一个数");
            int num = Convert.ToInt32(Console.ReadLine());
            int j = 0;
            int[] k = new int[Convert.ToString(num).Length];
            while (num > 0)
            {
                k[j]=num % 10;
                num /= 10;
                j++;
            }
            Console.Write("反向输出后：");
            foreach (var item in k)
            {
                Console.Write(item);
            }
        }
    }
}
