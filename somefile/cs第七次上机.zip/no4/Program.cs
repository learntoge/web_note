﻿namespace no4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("请输入班级中的人数");
            try
            {
                int p = Convert.ToInt32(Console.ReadLine());
                for (int i = 0; i < p; i++)
                {
                    Console.WriteLine("****************************************");
                    Console.WriteLine("请输入第{0}位学生的成绩",i+1);
                    int sum = 0;
                    for (int j = 0; j < 3;)
                    {
                    c:
                        Console.WriteLine("请输入第{0}门科目的成绩:", j + 1);

                        try
                        {
                            int a = Convert.ToInt32(Console.ReadLine());
                            if (a >= 0 && a <= 100)
                            {
                                sum += a;
                                j++;
                            }
                            else
                            {
                                Console.WriteLine("你输入的数据不在0-100");
                                goto c;
                            }
                        }
                        catch
                        {
                            Console.WriteLine("你输入的数据不合法");
                            goto c;
                        }

                    }
                    Console.WriteLine("第{0}位学生的总成绩为：{1}分，平均分为：{2:f2}", i+1,sum, sum / 3.0);

                }
            }
            catch (Exception ex) {
            Console.WriteLine("班级数据不合法");
            Console.WriteLine(ex.ToString());

            }
            
        }
    }
}
