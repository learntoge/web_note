namespace no5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string a = textBox1.Text;
            int i = 0;
            foreach (var item in a)
            {
                if (Convert.ToInt32(item)>=60&& Convert.ToInt32(item)<=90|| Convert.ToInt32(item)>=97&& Convert.ToInt32(item) <= 122)
                {
                    i++;
                }
            }
            label2.Text = "���ַ����й��У�"+i.ToString()+"����ĸ";
        }
    }
}
