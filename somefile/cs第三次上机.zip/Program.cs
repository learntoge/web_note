﻿namespace three
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //方法1
            int num1 = 52;
            int num2 =18;
            int num3;
            num3 = num1;
            num1 = num2;
            num2 = num3;
            Console.WriteLine("交换后num1={0},num2={1}", num1, num2);

        }
    }
}
