﻿//using System;
//using WMPLib;

//namespace five
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.Title = "音乐演奏器";
//            while (true) {
//                ConsoleKeyInfo ci = Console.ReadKey(true);
//                char c = ci.KeyChar;
//                Console.WriteLine(ci.KeyChar);
//                WindowsMediaPlayer wm = new WindowsMediaPlayer();
//                wm.URL = @"D:\她只是我的妹妹.mp3";
//            }
//        }
//    }
//}

using System;
using WMPLib;

namespace five
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "音乐演奏器";
            WindowsMediaPlayer wm = new WindowsMediaPlayer();
            wm.URL = @"D:\Users\huangsir\Downloads\obj_w5zDlMODwrDDiGjCn8Ky_14051473548_25f9_8155_4844_fd127b1ddb9ac653979b6fa83354de1a.mp3";
            while (true)
            {
                ConsoleKeyInfo ci = Console.ReadKey(true);

                // 播放音乐
                wm.controls.play();

            }
            
        }
    }
}
//using System;
//using WMPLib;

//namespace five
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.Title = "音乐演奏器";
//            WindowsMediaPlayer wm = new WindowsMediaPlayer();


//            while (true)
//            {
//                ConsoleKeyInfo ci = Console.ReadKey(true);
//                //char c = ci.KeyChar;
//                //Console.WriteLine(ci.KeyChar);
//                wm.URL = @"D:\她只是我的妹妹.mp3";
//                // 播放音乐
//                wm.controls.play();
//            }
//        }
//    }
//}


