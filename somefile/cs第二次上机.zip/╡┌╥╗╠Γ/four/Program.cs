﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace four
{
    class Program
    {
        static void Main(string[] args)
        {
            int chinese = 90;
            int math = 80;
            int english = 63;
            int sum = chinese + math + english;
            double pj = sum/ 3.0;
            //double pj = sum / 3;

            Console.WriteLine("成绩总分为：{0}，平均分为：{1}",sum,pj);
        }
    }
}
