﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace first_and_two
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("请输入你的姓名：");
            string name = Console.ReadLine(); 
            int age = 20;
            char genner = '男';
            //方法1
            Console.WriteLine("请输入你的电话：");
            int phone = Convert.ToInt32(Console.ReadLine());
            //方法2
            //int phone =int.Parse( Console.ReadLine());
            Console.WriteLine("我叫{0}，我今年{1}岁了，我时{2}生，我的电话是{3}", name, age, genner, phone);
            Console.Read();

        }
    }
}
/*
 Console.WriteLine("请输入你的姓名：");
            string name = Console.ReadLine();
            int age = 20;
            char genner = '男';
            //方法1
            Console.WriteLine("请输入你的电话：");
            int phone = Convert.ToInt32(Console.ReadLine());
            //方法2
            //int phone =int.Parse( Console.ReadLine());

            Console.WriteLine("我叫{0}，我今年{1}岁了，我时{2}生，我的电话是{3}", name, age, genner,phone);
            Console.Read();
 */

/*
             string name = "张三";
            int age = 18;
            char genner = '男';
            int phone = 13222222;
            Console.WriteLine("我叫{0}，我今年{1}岁了，我时{2}生，我的电话是{3}", name, age, genner, phone);
            Console.Read();
*/

