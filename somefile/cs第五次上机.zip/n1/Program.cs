﻿namespace n1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("请输入你的月收入和三险一金（元），输入格式：5000 100");
            string data = Console.ReadLine();
            string[] d=data.Split(' ');
            //Console.WriteLine(d[1]);
             int money_m = int.Parse(d[0]);
             int money_sx = int.Parse(d[1]);
            double geshui = 0.0;
            if (money_m-money_sx>5000)
            {

                if (money_m - money_sx-5000 < 3000)
                {
                    geshui = (money_m - money_sx - 5000) * 0.03;
                }
                else if (money_m - money_sx - 5000>=3000&& money_m - money_sx - 5000<12000)
                {
                    geshui = (money_m - money_sx - 5000) * 0.1-210;

                }
                else if (money_m - money_sx - 5000 >= 12000 && money_m - money_sx - 5000 < 25000)
                {
                    geshui = (money_m - money_sx - 5000) * 0.2-1410;

                }
                else if (money_m - money_sx - 5000 >= 25000 && money_m - money_sx - 5000 < 35000)
                {
                    geshui = (money_m - money_sx - 5000) * 0.25 -2660;

                }
                else if (money_m - money_sx - 5000 >= 35000 && money_m - money_sx - 5000 < 55000)
                {
                    geshui = (money_m - money_sx - 5000) * 0.3 - 4410;

                }
                else if (money_m - money_sx - 5000 >= 55000 && money_m - money_sx - 5000 < 80000)
                {
                    geshui = (money_m - money_sx - 5000) * 0.3 - 7160;

                }
                else if (money_m - money_sx - 5000 >= 80000)
                {
                    geshui = (money_m - money_sx - 5000) * 0.45 - 15160;

                }
            }
            
            Console.WriteLine("该用户需要缴纳个人所得税{0:f2}元",geshui);



        }
    }
}
