﻿namespace n2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("请输入用户名");
            string name = Console.ReadLine();
            Console.WriteLine("请输入密码");
            string psd = Console.ReadLine();
            if (name=="admin"&&psd=="88888")
            {
                Console.WriteLine("用户名密码正确");
            }
            else
            {
                if (name!="admin")
                {
                    Console.WriteLine("用户名错误！");
                }
                else
                {
                    Console.WriteLine("密码错误");
                }
            }

        }
    }
}
