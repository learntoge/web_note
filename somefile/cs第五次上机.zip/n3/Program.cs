﻿namespace n3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //单分支if
            Console.WriteLine("请输入学员的成绩");
            int a = int.Parse(Console.ReadLine());
            if (a >= 90)
            {
                Console.WriteLine('A');
            }
            if (a >= 80&&a<90)
            {
                Console.WriteLine('B');
            }
            if (a >= 70 && a < 80)
            {
                Console.WriteLine('C');
            }
            if (a >= 60 && a < 70)
            {
                Console.WriteLine('D');
            }
            if (a < 60)
            {
                Console.WriteLine('E');
            }

            // IF ELSE嵌套
            //if (a >= 90)
            //{
            //    Console.WriteLine('A');
            //}
            //else
            //{
            //    if (a >= 80)
            //    {
            //        Console.WriteLine('B');
            //    }
            //    else
            //    {
            //        if (a >= 70 )
            //        {
            //            Console.WriteLine('C');
            //        }
            //        else
            //        {
            //            if (a >= 60 )
            //            {
            //                Console.WriteLine('D');
            //            }
            //            else
            //            {
                            
            //                    Console.WriteLine('E');
                            
            //            }
            //        }
                   
            //    }
            //}
            ////if - elseif else
            //if (a >= 90)
            //{
            //    Console.WriteLine('A');
            //}
            //else if (a >= 80)
            //{
            //    Console.WriteLine('B');
            //}
            //else if (a >= 70)
            //{
            //    Console.WriteLine('C');
            //}
            //else if (a >= 60)
            //{
            //    Console.WriteLine('D');
            //}
            //else 
            //{
            //    Console.WriteLine('E');
            //}
            

        }
    }
}
