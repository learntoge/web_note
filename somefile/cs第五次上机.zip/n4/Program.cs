﻿namespace n4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("输入你购买电器的价格");
            int a =int.Parse(Console.ReadLine());
            string j = "";
            if (a < 1666)
            {
                j = "参加幸运抽奖";
            }
            else
            {
                if (a<2666)
                {
                    j = "电磁炉1个";
                }
                else
                {
                    j = "电压力锅1个";
                }
            }
            Console.WriteLine("可以获得的优惠：{0}",j);
        }
    }
}
