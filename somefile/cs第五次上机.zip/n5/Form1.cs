namespace n5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int r;
        private void button1_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            r = random.Next(1, 101);
            textBox1.Text = "";


        }

        private void button2_Click(object sender, EventArgs e)
        {
            label2.Text = "�յ��ǣ�" + r.ToString();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = label2.Text = label3.Text = "";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }


        private void textbox1_keydown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                int n = int.Parse(textBox1.Text);
                textBox1.Text = "";

                if (n > r)
                {
                    label3.Text = "����";
                    textBox1.Focus();
                }
                else if (n < r)
                {
                    label3.Text = "С��";
                    textBox1.Focus();

                }
                else
                {
                    label3.Text = "��������¶��ˣ�";

                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
