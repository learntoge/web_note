﻿namespace no1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("请输入年份");
                int year = int.Parse(Console.ReadLine());
                try
                {
                    Console.WriteLine("请输入月份");
                    int month = int.Parse(Console.ReadLine());
                    int day;
                    switch(month)
                    {
                        case 1:
                        case 3:
                        case 5:
                        case 7:
                        case 8:
                        case 10:
                        case 12:
                            day = 31;
                            break;
                        case 2:
                            if (year %400==0||(year%4==0&&year%100!=0))
                            {
                                day = 29;
                                break;
                         }
                            else
                            {
                                day=28;
                                break;
                            }

                        default:
                            day = 30; break;

                    }
                    Console.WriteLine("{0}年{1}月是{2}天",year,month,day);
                }
                catch { Console.WriteLine("你输入的月份不合法！"); }
            }
            catch { Console.WriteLine("你输入的年份不合法！"); }
        }
    }
}
