﻿namespace no2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int sum = 0,sumj=0,sumo=0;
            for (int i = 1; i < 101; i++)
            {
                if (i%2!=0)
                {
                    sumj += i;
                }
                else
                {
                    sumo += i;
                }
                sum += i;
            }
            Console.WriteLine("1-100整数和为：{0}\n奇数和为：{1}\n偶数和为：{2}",sum,sumj,sumo);

        }
    }
}
