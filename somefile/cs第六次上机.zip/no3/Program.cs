﻿namespace no3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("------猜拳小游戏------\n");
            Console.ForegroundColor= ConsoleColor.Red;
            Console.WriteLine("1.石头\n2.剪刀\n3.布\n4.退出");
            Console.ForegroundColor = ConsoleColor.Cyan;
            try
            {
                int sum = 0;
                while (true) {
                     Console.WriteLine("请输入你的选择：");
                    
                    int choose = int.Parse(Console.ReadLine());
                if (choose >= 1 && choose <= 3)
                {

                    Random r = new Random();
                    int commputer = r.Next(1, 4);
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    switch (commputer)
                    {
                        case 1:
                            {
                                Console.WriteLine("电脑出的石头");
                                break;
                            }
                        case 2:
                            {
                                Console.WriteLine("电脑出的剪刀");
                                break;
                            }
                        case 3:
                            {
                                Console.WriteLine("电脑出的布");
                                break;
                            }

                    }
                    switch (choose - commputer)
                    {
                        case -2:
                        case 1:
                            {
                                Console.WriteLine("玩家胜利");
                                 sum++;
                                    break;
                            }
                        default:
                            {
                                Console.WriteLine("电脑胜利"); break;

                            }
                    }


                }

                else if (choose == 4)
                {
                        Console.WriteLine("本次游戏你的得分：{0}", sum);
                        break;
                }
                
                else
                {
                    Console.WriteLine("你输入的范围不对！");
                }
                }

            }
            catch { 
                    Console.WriteLine("你输入的数据不合法！");

            }
        }
    }
}
