﻿namespace no4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("请输入星期：（1-7）");
            try
            {

            int week = int.Parse(Console.ReadLine());
            switch (week)
            {
                case 1:
                    {
                        Console.WriteLine("干煸四季豆6元");
                        break;
                    }
                case 2:
                  {
                        Console.WriteLine("蒜蓉油麦菜4元");
                        break;
                    }
                case 3:
                    {
                        Console.WriteLine("白水鸡8元");
                        break;
                    }
                case 4:
                     {
                        Console.WriteLine("清炒笋丝6元");
                         break;
                    }
                case 5:
                    {
                        Console.WriteLine("西红柿炖牛腩15元");
                        break;
                    }
                case 6:
                    {
                        Console.WriteLine("水煮鱼18元");
                        break;
                    }
                case 7:
                    {
                        Console.WriteLine("酸菜鱼18元");
                        break;
                    }
                default:
                    {
                        Console.WriteLine("你输入的数据不在合法范围");
                        break;
                    }
             }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
    }
}
