﻿namespace no5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("请输入用户名");
            string name = Console.ReadLine();
            Console.WriteLine("请输入密码");
            string pwd = Console.ReadLine();
            int index = 3;
            while((name!="admin"||pwd!= "88888")&&index>0) {
                Console.WriteLine("你还有{0}次机会", index);
                if (name != "admin")
                {
                    Console.WriteLine("用户名错误，请重新输入用户名");
                    name = Console.ReadLine();
                }
                if (pwd != "88888")
                {
                    Console.WriteLine("密码错误，请重新输入密码");
                    pwd = Console.ReadLine();
                }
                
                
                index--;
            }
            if (name == "admin" && pwd == "88888")
            {
                Console.WriteLine("登录成功");
            }
            else
            {
                Console.WriteLine("登陆失败，重试已超过三次，请明天再试");
            }
        }
    }
}
