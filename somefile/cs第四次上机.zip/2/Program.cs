﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;
            double sum;
            Console.WriteLine("买几条裤子");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("买几件T恤");
            b = Convert.ToInt32(Console.ReadLine());
            sum = a * 120 + b * 85;
            Console.WriteLine("小明需付的总金额为：{0}元，打8.8折后需{1:f2}元",sum,sum*0.88);
        }
    }
}
