﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _3
{
    public partial class 体会类型转换 : Form
    {
        public 体会类型转换()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

       

        private void number1_TextChanged(object sender, EventArgs e)
        {

        }

        private void sum_Click(object sender, EventArgs e)
        {
        
            if (number1.Text == "" || number2.Text == "")
            {
                MessageBox.Show("操作数不能为空", "警告信息", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            }
            else
            {
                try { sumnum.Text = Convert.ToString(Convert.ToDouble(number1.Text) + Convert.ToDouble(number2.Text)); 
                }
                catch{
                MessageBox.Show("操作数不合法", "警告信息", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                         
            }
        
        }

        private void clear_Click(object sender, EventArgs e)
        {
            number1.Text = "";
            number2.Text = "";
            sumnum.Text = "";

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
