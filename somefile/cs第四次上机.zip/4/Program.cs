﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _4
{
    class Program
    {
        static void Main(string[] args)
        {
            int chinese, math;
            Console.WriteLine("请输入语文成绩");
            chinese =Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("请输入数学成绩");
            math = Convert.ToInt32(Console.ReadLine());
            
            //Console.WriteLine("该生的语文和数学成绩都大于90分");
            
            //if (chinese > 90 && math > 90)
            //{
            //    Console.WriteLine("True");
            //}
            //else {
            //    Console.WriteLine("False");
            //}
            //Console.WriteLine("语文和数学有一门是大于90分的");
            //if (chinese > 90 || math > 90)
            //{
            //    Console.WriteLine("True");
            //}
            //else 
            //{ 
            //    Console.WriteLine("false");
            //}
            string a = (chinese > 90 && math > 90) ? "True" : "Flase";
            string b = (chinese > 90 || math > 90) ? "True" : "Flase";
            Console.WriteLine("该生的语文和数学成绩都大于90分");
            Console.WriteLine(a);
            Console.WriteLine("语文和数学有一门是大于90分的");
            Console.WriteLine(b);




        }
    }
}
