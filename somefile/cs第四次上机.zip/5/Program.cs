﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("请输入一个年份：");
            int year = Convert.ToInt32(Console.ReadLine());
            if ((year % 400 == 0) || (year % 4 == 0 && year % 100 != 0))
            {
                Console.WriteLine("是");
            }
            else {
                Console.WriteLine("不是");
            }
        }
    }
}
