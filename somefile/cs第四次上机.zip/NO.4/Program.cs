﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NO._4
{
    class Program
    {
        static void Main(string[] args)
        {
            double a, b;
            double h;
            double area;
            Console.WriteLine("请输入梯形的上边");
            a = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("请输入梯形的下边");
            b = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("请输入梯形的高");
            h = Convert.ToDouble(Console.ReadLine());
            area = (a + b) * h / 2.0;
            Console.WriteLine("该梯形的面积为{0:f3}",area);

        }
    }
}
